#!/usr/bin/env python
#-*- conding:utf-8 -*-
import zmq
import time

localhost = '127.0.0.1'
port = '5556'

def run():
    context = zmq.Context()
    print('Collector ... {} {}'.format(localhost, port))
    socket = context.socket(zmq.PULL)
    socket.bind('tcp://{}:{}'.format(localhost, port))
    
    while True:
        msg = socket.recv()
        print('Collector receive message {}'.format(msg))
        time.sleep(0.05)

if __name__ == '__main__':
    run()

