#!/usr/bin/env python
#-*- conding:utf-8 -*-
import zmq
import time

localhost = '127.0.0.1'
port = '5555'

def run():
    context = zmq.Context()
    #  Socket to talk to server
    print('Start to producer... {} {}'.format(localhost, port))
    socket = context.socket(zmq.PUSH)
    socket.bind('tcp://{}:{}'.format(localhost, port))
    time.sleep(0.5)
    # Do 10 Push
    for i in range(10):
        msg = 'Hello world {}'.format(i)
        print('Producer push message {}'.format(msg))
        socket.send(msg)
        time.sleep(1)

if __name__ == '__main__':
    run()

