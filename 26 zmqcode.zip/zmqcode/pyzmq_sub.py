#!/usr/bin/env python
# -*- coding:utf-8 -*-
import zmq
import time

localhost = '127.0.0.1'
port = '5555'

def run():
    print('Start to subscribe... %s %s' % (localhost, port))
    context = zmq.Context()
    socket = context.socket(zmq.SUB)
    socket.connect('tcp://{}:{}'.format(localhost, port))
    socket.setsockopt(zmq.SUBSCRIBE, '')
    while True:
        message = socket.recv()
        print('Recieved publisher: [ %s ]' % message)

        time.sleep(0.05)
    socket.close()

if __name__ == '__main__':
    run()