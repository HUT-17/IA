#!/usr/bin/env python
#-*- conding:utf-8 -*-
import zmq
import time

localhost = '127.0.0.1'
pull_port = '5555'
push_port = '5556'

def run():
    context = zmq.Context()
    print('Recive ... {} {}'.format(localhost, pull_port))
    receive = context.socket(zmq.PULL)
    receive.connect('tcp://{}:{}'.format(localhost, pull_port))
    print('Sender ... {} {}'.format(localhost, push_port))
    sender = context.socket(zmq.PUSH)
    sender.connect('tcp://{}:{}'.format(localhost, push_port))
    while True:
        msg = receive.recv()
        print('Consumer receive message {}'.format(msg))
        sender.send(msg)
        time.sleep(0.05)

if __name__ == '__main__':
    run()

