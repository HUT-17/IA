//
//  client.cpp
//  Client
//
//  Created by zhimin.liang on 2021/2/24.
//

#include <iostream>
#include <unistd.h>
#include "zmq.h"

std::string localhost = "127.0.0.1";
int port = 5555;

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Connecting to Server: " << localhost << " " << port << std::endl;
    void *context = zmq_ctx_new();
    void *socket = zmq_socket(context, ZMQ_REQ);
    std::string address = "tcp://" + localhost + ":" + std::to_string(port);
    int ret = zmq_connect(socket, address.c_str());
    if (ret != 0) {
        return -1;
    }
    for (int request=0; request<10; request++) {
        std::cout << "Sending request " << request << std::endl;
        std::string sendmsg = "Hello " + std::to_string(request);
        zmq_send(socket, sendmsg.c_str(), sendmsg.size(), 0);
        sleep(1);
        zmq_msg_t msg;
        zmq_msg_init(&msg);
        zmq_msg_recv(&msg, socket, ZMQ_NULL);
        size_t size = zmq_msg_size(&msg);
        void *pbuffer = malloc(size+1);
        memcpy(pbuffer, zmq_msg_data(&msg), size);
//        void *pbuffer = zmq_msg_data(&msg);
        std::cout << "Received reply " << (unsigned char *)pbuffer << std::endl;
        zmq_msg_close(&msg);
//        sleep(1);
    }
    
    return 0;
}
