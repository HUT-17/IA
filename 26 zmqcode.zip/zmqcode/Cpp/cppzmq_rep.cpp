//
//  server.cpp
//  Server
//
//  Created by zhimin.liang on 2021/2/24.
//

#include <iostream>
#include <stdio.h>
#include <vector>
#include "zmq.h"

std::string localhost = "127.0.0.1";
int port = 5555;

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Start to CPP Server " << localhost << " " << port << std::endl;
    void *context = zmq_ctx_new();
    void *socket = zmq_socket(context, ZMQ_REP);
    std::string address = "tcp://" + localhost + ":" + std::to_string(port);
    int ret = zmq_bind(socket, address.c_str());
    if (ret != 0) {
        return -1;
    }
    while (true) {
        std::vector <unsigned char>data_buffer;
        data_buffer.clear();
        zmq_pollitem_t pollitem[1];
        pollitem[0].socket = socket;
        pollitem[0].events = ZMQ_POLLIN;
        int rc = zmq_poll(pollitem, 1, 500);
        if (rc>0) {
            zmq_msg_t msg;
            zmq_msg_init(&msg);
            zmq_msg_recv(&msg, socket, ZMQ_NOBLOCK);
            void *pbuffer = zmq_msg_data(&msg);
            size_t len = zmq_msg_size(&msg);
            for (int i=0; i<len; i++) {
                data_buffer.push_back(((unsigned char *)pbuffer)[i]);
            }
            std::cout << "Recv : " << (unsigned char *)pbuffer << std::endl;
            std::string recv = "Recv OK";
            zmq_send(socket, recv.c_str(), recv.size(), 0);
            zmq_msg_close(&msg);
        }
    }
    return 0;
}
