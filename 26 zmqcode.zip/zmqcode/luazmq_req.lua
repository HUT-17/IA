#!/usr/bin/env lua

local zmq = require("lzmq")
local zpoller = require("lzmq.poller")

local localhost = '127.0.0.1'
local port = '5555'

function run_client()
    print(string.format('Connecting to server... %s %s', localhost, port))
    local context = zmq.context()
    local socket, err = context:socket(zmq.REQ, {connect = string.format('tcp://%s:%s', localhost, port)})
    for request=1, 10 do
        print('Sending request ', request)
        socket:send(string.format('Hello Lua REQ %d', request))
        message = socket:recv()
        if message then
            print(string.format('Received reply %d [ %s ]', request, message))
        end
        os.execute("sleep 1")
    end
end

run_client()