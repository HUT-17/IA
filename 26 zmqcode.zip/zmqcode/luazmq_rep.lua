#!/usr/bin/env lua

local zmq = require("lzmq")
local zpoller = require("lzmq.poller")

local localhost = '127.0.0.1'
local port = '5555'

function run_server()
    print(string.format('Start to server %s %s', localhost, port))
    local context = zmq.context()
    local socket, err = context:socket(zmq.REP, {bind = string.format('tcp://%s:%s', localhost, port)})
    local poller = zpoller.new(1)
    poller:add(socket, zmq.POLLIN,  function()
        local msg = socket:recv()
        if msg then
            print('Received msg: ', msg)
            socket:send('Reply OK')
        end
    end)
    poller:start()
end

run_server()