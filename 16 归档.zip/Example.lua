local DMM = require("DMM")

--ExampleArr : local Arr = {1,2,3,4,5}

function calibrationDMMBoard( setVoltageArray )
	local xArray = setVoltageArray
	local yArray = {}
	for i=1,#xArray do
		yArray[i] = DMM.setVoltage_getDMMValue(xArray[i])
	end

	local sumXY = 0
	local xAverage = 0
	local yAverage = 0
	local sumX2 = 0
	local length = #xArray

	for i=1,length do
		sumXY 		= sumXY 	+ xArray[i]*yArray[i]
		xAverage 	= xAverage 	+ xArray[i]
		yAverage 	= yAverage 	+ yArray[i]
		sumX2 		= sumX2 	+ xArray[i]* xArray[i]
	end
	xAverage = xAverage/length
	yAverage = yAverage/length
	
	--拟合直线的斜率
	local a = (sumXY - length*xAverage*yAverage)/(sumX2 - length*xAverage*xAverage)
	local b = yAverage - a*xAverage
	print("\r\n\r\n拟合直线y=ax+b :\r\na="..tostring(a).."\r\nb="..tostring(b))



	-- body
end
local setVoltageArray = {1,3.3,5,10,16}
calibrationDMMBoard(setVoltageArray)
