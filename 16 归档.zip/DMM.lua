local DMM = {}

function stringReverse(s)
	local str = tostring(s)
    local r = ""
    for i = #s, 1, -1 do
        r = r .. string.sub(s, i, i)
    end
    return r
end
math.randomseed(stringReverse(tostring(os.time())))
function setVoltage( voltage )
	print("Set voltage = "..tostring(voltage))
end

function getDMMValue_Voltage( voltage )
	if voltage then
		local val = tonumber(voltage)
		
		val = val + val/20*math.random()-val/40
		print("Get DMMValue = "..tostring(val).."V")
		return val
	else
		print("Get DMMValue FAIL")
		return 0
	end
	-- body
end

function DMM.setVoltage_getDMMValue( voltage )
	setVoltage(voltage)
	return getDMMValue_Voltage(voltage)
	-- body
end

print("Success Load DMM Module")
return DMM